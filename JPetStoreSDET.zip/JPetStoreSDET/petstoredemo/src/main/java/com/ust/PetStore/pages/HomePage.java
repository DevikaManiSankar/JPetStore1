package com.ust.PetStore.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.PetStore.reusable.ReusableFunction;

public class HomePage {
	
	WebDriver driver;
	ReusableFunction rf;
	
	public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver,this);
        rf = new ReusableFunction(driver);
    }
	
	@FindBy(css="div#MenuContent a:nth-child(3)")
	public WebElement signin;
	
	@FindBy(xpath="//div[@id=\"QuickLinks\"]/a[2]")
	public WebElement dogs;
	
	public HomePage click(WebElement element) {
		rf.clickElement(element);
		return this;
	}
	
	public boolean checkUrl(String url) {
		return rf.checkurl(url);
	}
	

}
