package com.ust.PetStore.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.PetStore.reusable.ReusableFunction;

public class SignupPage {
	
	WebDriver driver;
	ReusableFunction rf;
	
	@FindBy(xpath="//input[@name=\"username\"]")
	public WebElement username;
	
	@FindBy(xpath="//input[@name=\"password\"]")
	public WebElement pass;
	
	@FindBy(xpath="//input[@name=\"repeatedPassword\"]")
	public WebElement repeatedPass;
	
	@FindBy(xpath="//input[@name=\"account.firstName\"]")
	public WebElement fname;
	
	@FindBy(xpath="//input[@name=\"account.lastName\"]")
	public WebElement lname;
	
	@FindBy(xpath="//input[@name=\"account.email\"]")
	public WebElement email;
	
	@FindBy(xpath="//input[@name=\"account.phone\"]")
	public WebElement phone;
	
	@FindBy(xpath="//input[@name=\"account.address1\"]")
	public WebElement address1;
	
	@FindBy(xpath="//input[@name=\"account.address2\"]")
	public WebElement address2;
	
	@FindBy(xpath="//input[@name=\"account.city\"]")
	public WebElement city;
	
	@FindBy(xpath="//input[@name=\"account.state\"]")
	public WebElement state;
	
	@FindBy(xpath="//input[@name=\"account.zip\"]")
	public WebElement zip;
	
	@FindBy(xpath="//input[@name=\"account.country\"]")
	public WebElement country;
	
	@FindBy(css="select[name=\"account.favouriteCategoryId\"]")
	public WebElement category;
	
	@FindBy(xpath="//select[@name=\"account.favouriteCategoryId\"]/option[2]")
	public WebElement dogs;
	
	@FindBy(css="input[name=\"account.listOption\"]")
	public WebElement list;
	
	@FindBy(css="input[name=\"account.bannerOption\"]")
	public WebElement banner;
	
	@FindBy(xpath="//input[@name=\"newAccount\"]")
	public WebElement saveAccount;
	
	public SignupPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver,this);
        rf = new ReusableFunction(driver);
    }
	
	public SignupPage inpuString(WebElement el,String txt) {
		rf.insertText(txt, el);
		return this;
	}
	
	public boolean insertWorked(WebElement el,String txt) {
		return rf.insertWorked(txt, el);
	}
	
	public SignupPage click(WebElement el) {
        rf.clickElement(el);
        return this;
    }
	
    public boolean checkUrl(String url) {
        return rf.checkurl(url);
    }
    
    public boolean isPresent(WebElement element) {
		return rf.isPresent(element);
	}
	
	public boolean isNotPresent(WebElement el) {
		return rf.isNotPresent(el);
	}
}
