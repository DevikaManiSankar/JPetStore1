package com.ust.PetStore.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.PetStore.reusable.ReusableFunction;

public class DogsPage {
	
	WebDriver driver;
	ReusableFunction rf;
	
	public DogsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver,this);
        rf = new ReusableFunction(driver);
    }

	@FindBy(xpath="(//td[1])[3]")
	public WebElement dalmation;
	
	@FindBy(xpath="(//td[5])[1]")
	public WebElement addToCart;
	
	@FindBy(linkText="Proceed to Checkout")
	public WebElement checkout;
	
	@FindBy(css="input[name=\"newOrder\"]")
	public WebElement cont;
	
	@FindBy(linkText="Confirm")
	public WebElement confirm;
	
	public DogsPage click(WebElement el) {
        rf.clickElement(el);
        return this;
    }
	
    public boolean containsInUrl(String url) {
    	return rf.urlContains(url);
    }
    
    public boolean isPresent(WebElement element) {
		return rf.isPresent(element);
	}
	
	public boolean isNotPresent(WebElement el) {
		return rf.isNotPresent(el);
	}
}
