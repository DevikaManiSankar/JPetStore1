package com.ust.PetStore.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.PetStore.reusable.ReusableFunction;

public class LoginPage {

	WebDriver driver;
	ReusableFunction rf;
	
	@FindBy(xpath="(//div[@id=\"Catalog\"]//input)[1]")
	public WebElement username;
	
	@FindBy(xpath="(//div[@id=\"Catalog\"]//input)[2]")
	public WebElement password;
	
	@FindBy(xpath="//input[@name=\"signon\"]")
	public WebElement login;
	
	@FindBy(linkText="Register Now!")
	public WebElement register;
	
	@FindBy(xpath="//ul[@class=\"messages\"]")
	public WebElement error;
	
	public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver,this);
        rf = new ReusableFunction(driver);
    }
	
	public LoginPage click(WebElement element) {
		rf.clickElement(element);
		return this;
	}
	
	public boolean checkUrl(String url) {
		return rf.checkurl(url);
	}
	
	public LoginPage insertText(WebElement el,String txt) {
		el.clear();
		rf.insertText(txt, el);
		return this;
	}
	
	public boolean insertWorked(WebElement el,String txt) {
        return rf.insertWorked(txt, el);
    }
	
	public boolean isPresent(WebElement element) {
		return rf.isPresent(element);
	}
	
	public boolean isNotPresent(WebElement el) {
		return rf.isNotPresent(el);
	}
}
