package com.ust.PetStore.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.ust.PetStore.base.SetUp;
import com.ust.PetStore.pages.DogsPage;
import com.ust.PetStore.pages.HomePage;
import com.ust.PetStore.pages.LoginPage;
import com.ust.PetStore.pages.SignupPage;

public class addToCartTest extends SetUp {

	HomePage hpage;
	LoginPage lpage;
	SignupPage spage;
	DogsPage dpage;

	@Test(priority = 0)
	public void loadHome() {
		driver.get(properties.getProperty("home"));
		waits();
		hpage = new HomePage(driver);
		Assert.assertTrue(hpage.checkUrl(properties.getProperty("home")), "Failed to load home page.");
	}

	@Test(priority = 1)
	public void loadLogin() {
		hpage.click(hpage.signin);
		lpage = new LoginPage(driver);
		waits();
		Assert.assertTrue(lpage.isPresent(lpage.username), "Failed to load login page.");
	}

	@Test(priority = 2)
	public void login() {
		lpage.insertText(lpage.username, properties.getProperty("newusername"));
		lpage.insertText(lpage.password, properties.getProperty("password"));
		lpage.click(lpage.login);
		waits();
		Assert.assertTrue(hpage.checkUrl(properties.getProperty("home")), "Failed to load home page.");
	}

	@Test(priority = 3)
	public void selectDog() {
		hpage.click(hpage.dogs);
		dpage = new DogsPage(driver);
		waits();
		Assert.assertTrue(dpage.isPresent(dpage.dalmation), "Failed to select dog.");
	}

	@Test(priority = 4)
	public void clickDalmation() {
		dpage.click(dpage.dalmation);
		waits();
	}

	@Test(priority = 5)
	public void clickAddtoCart() {
		dpage.click(dpage.addToCart);
        waits();
	}
	
	@Test(priority = 6)
	public void clickCheckout() {
		dpage.click(dpage.checkout);
        waits();
	}
	
	@Test(priority = 7)
	public void clickContinue() {
		dpage.click(dpage.cont);
        waits();
	}
	
	@Test(priority = 8)
	public void clickonfirm() {
		dpage.click(dpage.confirm);
        waits();
        Assert.assertTrue(dpage.containsInUrl(properties.getProperty("confirmation")),"Faile to checkout successfully.");
	}
}
