package com.ust.PetStore.tests;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.PetStore.base.SetUp;
import com.ust.PetStore.pages.HomePage;
import com.ust.PetStore.pages.LoginPage;
import com.ust.PetStore.pages.SignupPage;
import com.ust.PetStore.utils.ExtentReportsListener;

@Listeners(ExtentReportsListener.class)
public class SignUpTest extends SetUp{
	
	HomePage hpage;
	LoginPage lpage;
	SignupPage spage;
	
	@Test(priority = 0)
	public void loadHome() {
		driver.get(properties.getProperty("home"));
		waits();
		hpage = new HomePage(driver);
		Assert.assertTrue(hpage.checkUrl(properties.getProperty("home")),"Failed to load home page.");
	}
	
	@Test(priority = 1)
	public void loadLogin() {
		hpage.click(hpage.signin);
		lpage = new LoginPage(driver);
		waits();
		Assert.assertTrue(lpage.isPresent(lpage.username),"Failed to load login page.");
	}
	
	@Test(priority = 2)
    public void loadSignup() {
		lpage.click(lpage.register);
		spage = new SignupPage(driver);
		waits();
		Assert.assertTrue(spage.isPresent(spage.username),"Failed to load singup page.");
	}
	
	@Test(priority = 3)
	public void inputDetails() {
		spage.inpuString(spage.username,properties.getProperty("newusername"));
		spage.inpuString(spage.pass,properties.getProperty("password"));
		spage.inpuString(spage.repeatedPass,properties.getProperty("repeatedPass"));
		spage.inpuString(spage.fname,properties.getProperty("fname"));
		spage.inpuString(spage.lname,properties.getProperty("lname"));
		spage.inpuString(spage.email,properties.getProperty("email"));
		spage.inpuString(spage.phone,properties.getProperty("phone"));
		spage.inpuString(spage.address1,properties.getProperty("address1"));
		spage.inpuString(spage.address2,properties.getProperty("address2"));
		spage.inpuString(spage.city,properties.getProperty("city"));
		spage.inpuString(spage.state,properties.getProperty("state"));
		spage.inpuString(spage.zip,properties.getProperty("zip"));
		spage.inpuString(spage.country,properties.getProperty("country"));
	}
	
	@Test(priority = 4)
	public void selectCategory() {
		spage.click(spage.category);
        spage.click(spage.dogs);
	}
	
	@Test(priority = 5)
    public void checkMyList() {
		spage.click(spage.list);
	}
	
	@Test(priority = 6)
    public void checkMyBanner() {
        spage.click(spage.banner);
    }
	
	@Test(priority = 7)
	public void saveAccount() {
        spage.click(spage.saveAccount);
        waits();
        Assert.assertTrue(spage.checkUrl(properties.getProperty("home")),"Failed to save accoubt details.");
    }
	
	@Test(priority = 8)
    public void clicklogin() {
        hpage.click(hpage.signin);
        waits();
    }
	
	@Test(priority = 9)
	public void login() {
		lpage.insertText(lpage.username,properties.getProperty("newusername"));
        lpage.insertText(lpage.password,properties.getProperty("password"));
        lpage.click(lpage.login);
        waits();
        Assert.assertTrue(lpage.checkUrl(properties.getProperty("home")),"Failed to login.");
	}

}
