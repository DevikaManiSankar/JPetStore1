package runner;

import io.cucumber.testng.*;

@CucumberOptions(
		glue="step_definitions",
		features = "C:\\Users\\268879\\Desktop\\Foundation Exam\\PetStore\\src\\test\\resources\\features",
		plugin = {"pretty",
				"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
				"timeline:test-output-thread/"
		}
	)

public class TestRunner extends AbstractTestNGCucumberTests{

}
