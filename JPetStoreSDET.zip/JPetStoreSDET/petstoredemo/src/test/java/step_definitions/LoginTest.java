package step_definitions;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.DataProvider;

import com.ust.PetStore.pages.HomePage;
import com.ust.PetStore.pages.LoginPage;
import com.ust.PetStore.utils.ExcelDataReader;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginTest {
	
	WebDriver driver = Hooks.driver;
	Properties properties = Hooks.properties;
	HomePage hpage;
	LoginPage lpage;
	
	@DataProvider(name="invalidLogin")
	public Object[][] invalidLogin() throws IOException{
		return ExcelDataReader.readDataFromSheet(properties.getProperty("invalid"),properties.getProperty("excel"));
	}
	
	@Given("Iam already on homepage")
	public void iam_already_on_homepage() {
        driver.get(properties.getProperty("home"));
        hpage = new HomePage(driver);
    }
	
	@When("I click Signin button")
	public void i_click_Signin_button() {
        hpage.click(hpage.signin);
        Hooks.waits();
    }
	
	@Then("Iam redirected to signin page")
	public void redirected() {
		lpage = new LoginPage(driver);
        Assert.assertTrue(lpage.isPresent(lpage.username),"Failed to load login page.");
	}
	
	@When("I enter invalid {string} and {string}")
	public void i_enter_invalid_username_and_password(String username,String password) {
        lpage.insertText(lpage.username,username);
        lpage.insertText(lpage.password,password);
        lpage.click(lpage.login);
    }
	
	@Then("Error message is shown or Iam still in the same page")
	public void error_message_is_shown_or_Iam_still_in_the_same_page() {
        Hooks.waits();
        boolean success = true;
        if(lpage.checkUrl(properties.getProperty("login"))) {
        	success = true;
        }else {
        	success = false;
        }
        Assert.assertTrue(success,"Failed to cehck invalid data.");
    }
	
	@When("I enter valid username and password")
	public void i_enter_valid_username_and_password() {
		lpage.insertText(lpage.username,properties.getProperty("username"));
        lpage.insertText(lpage.password,properties.getProperty("pass"));
        lpage.click(lpage.login);
	}
	
	@Then("Iam redirected to home page")
	public void iam_redirected_to_home_page() {
		Hooks.waits();
        Assert.assertTrue(lpage.checkUrl(properties.getProperty("home")),"Failed to redirect to home page.");
    }
	
}
